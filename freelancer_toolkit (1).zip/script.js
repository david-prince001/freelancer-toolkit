
// Firebase config (dummy example, replace with yours)
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-project.firebaseapp.com",
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

function login() {
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider).then(() => alert("Logged in!"));
}

function showDashboard(invoices = []) {
  document.getElementById('dashboard').classList.remove('hidden');
  const total = invoices.reduce((sum, i) => sum + parseFloat(i.total || 0), 0);
  document.getElementById('totalEarnings').textContent = `$${total.toFixed(2)}`;
  document.getElementById('invoiceCount').textContent = invoices.length;
  const monthTotals = Array(12).fill(0);
  invoices.forEach(i => {
    const month = new Date().getMonth();
    monthTotals[month] += parseFloat(i.total || 0);
  });
  new Chart(document.getElementById("earningsChart"), {
    type: "bar",
    data: {
      labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
               "Aug", "Sep", "Oct", "Nov", "Dec"],
      datasets: [{
        label: "Earnings",
        data: monthTotals,
        backgroundColor: "#4f46e5"
      }]
    }
  });
}
